/*
 * encoding:utf-8
 * 
 * Autores: María Sánchez Marcos y Darío Megías Guerrero
 */
package P2;

public enum EstadosMotor {
    ENCENDIDO, APAGADO, ACELERANDO, FRENANDO;
}
