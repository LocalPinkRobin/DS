

package s1e1_darioymaria;

public class BicicletaMontana extends Bicicleta {

    BicicletaMontana(int id) {
        super(id);
    }
}
