
package s1e1_darioymaria;

public class BicicletaCarretera extends Bicicleta {
    
    BicicletaCarretera(int id) {
        super(id);
    }
}