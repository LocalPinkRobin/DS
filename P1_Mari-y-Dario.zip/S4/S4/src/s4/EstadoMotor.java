/*
 * encoding:utf-8
 * 
 * Autores: María Sánchez Marcos y Darío Megías Guerrero
 */
package s4;

public enum EstadoMotor {
    ENCENDIDO, APAGADO, ACELERANDO, FRENANDO;
}
