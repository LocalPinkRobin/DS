/*
 * encoding:utf-8
 * 
 * Autores: María Sánchez Marcos y Darío Megías Guerrero
 */
package s4;

public interface Filtro {
    
    public abstract double ejecutar(double revoluciones, EstadoMotor estadoMotor);
}
