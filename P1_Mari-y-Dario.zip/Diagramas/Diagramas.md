# Sesión 1, ejercicio obligatorio.
![S1](S1E1.png)
<br/>
<br/>
<br/>
# Sesión 2, ejercicio obligatorio.
![S2](S2.png)
<br/>
<br/>
<br/>
# Sesión 3, ejercicio obligatorio.
![S3E1](S3E1.png)
<br/>
<br/>
<br/>
# Sesión 4, ejercicio obligatorio.
![S4](S4.png)
