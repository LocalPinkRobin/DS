# Importante

Salen marcas de agua porque con la versión **16.1** no me deja activar la licencia de la guía docente y hemos tenido que usar la **copia de evaluación**
