# Importante

Esta sesión está hecha y compilada con **QT Creator** por lo tanto se recomienda abrir el archivo *S2.pro* con dicha aplicación
