#include "visitanteequipo.h"

VisitanteEquipo::VisitanteEquipo()
{

}
